﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
    public partial class teacherFacultyForm : Form
    {
        private int facultyId; // поле для хранения id факультета

        public teacherFacultyForm(int id) // конструктор с параметром
        {
            InitializeComponent();
            facultyId = id;
        }
        public void LoadTeacher()
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
        "SELECT t.teacher_id, t.FIO_teacher, t.experience,t.gender ,k.kafedra_name, f.faculty_name " +
        "FROM teacher t " +
        "JOIN kafedra k ON t.kafedra_id = k.kafedra_id " +
        "JOIN faculty f ON k.id_faculty = f.faculty_id " +
        "WHERE f.faculty_id = @id",
                db.GetConnection()
            );

            command.Parameters.AddWithValue("@id", facultyId);

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }
        public teacherFacultyForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }

        private void teacherFacultyForm_Load(object sender, EventArgs e)
        {
            LoadTeacher();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
