﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class chooseFacultyForm : Form
    {
        public chooseFacultyForm()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try { 
            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);
            } catch { }
        }

        private void chooseFacultyForm_Load(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
                "SELECT * FROM Faculty",
                db.GetConnection()
            );

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.Index < 0)
            {
                MessageBox.Show("Выберите факультет");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            teacherFacultyForm f2 = new teacherFacultyForm(id);
            f2.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
