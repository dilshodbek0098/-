﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
    public partial class facultyForm : Form
    {
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(facultyTxt.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(decanTxt.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
        public void LoadFaculty()
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
                "SELECT * FROM Faculty",
                db.GetConnection()
            );

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }
        public facultyForm()
        {
            InitializeComponent();
        }

        private void facultyForm_Load(object sender, EventArgs e)
        {
            LoadFaculty();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
            "INSERT INTO Faculty(faculty_name, dekan_name) VALUES(@name,@decan)",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = facultyTxt.Text;
            command.Parameters.Add("@decan", MySqlDbType.VarChar).Value = decanTxt.Text;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadFaculty();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            facultyTxt.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            decanTxt.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            MySqlCommand command = new MySqlCommand(
            "UPDATE Faculty SET faculty_name=@name, dekan_name=@dekan WHERE faculty_id=@id",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = facultyTxt.Text;
            command.Parameters.Add("@dekan", MySqlDbType.VarChar).Value = decanTxt.Text;
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;


            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadFaculty();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            MySqlCommand command = new MySqlCommand(
                "DELETE FROM Faculty WHERE faculty_id=@id",
                db.GetConnection()
            );

            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadFaculty();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
