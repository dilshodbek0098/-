﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class groupedDB : Form
    {
        public groupedDB()
        {
            InitializeComponent();
        }

        private void groupedDB_Load(object sender, EventArgs e)
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
        "SELECT f.faculty_name AS Факультет," +
        "f.dekan_name AS Декан,k.kafedra_name AS Кафедра, " +
        "k.graduating AS Выпускающая, t.fio_teacher AS Преподаватель, " +
        "t.teacher_id,t.experience,t.gender " +
        "FROM teacher t JOIN kafedra k ON t.kafedra_id = k.kafedra_id " +
        "JOIN faculty f ON k.id_faculty = f.faculty_id " +
        "ORDER BY f.faculty_name, k.kafedra_name, t.FIO_teacher;",
        db.GetConnection()
            );


            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }
    }
}
