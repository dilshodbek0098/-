﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class kafedraForm : Form
    {
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtFacultyID.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        public void LoadKafedra()
        {
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
                "SELECT * FROM Kafedra",
                db.GetConnection()
            );

            MySqlDataAdapter adapter = new MySqlDataAdapter();
            DataTable table = new DataTable();

            adapter.SelectCommand = command;
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }
        public kafedraForm()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
            "INSERT INTO Kafedra(kafedra_name,graduating,id_faculty) VALUES(@name,@grad,@idfac)",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = txtName.Text;
            command.Parameters.Add("@grad", MySqlDbType.Bit).Value = checkBoxGrad.Checked;
            command.Parameters.Add("@idfac", MySqlDbType.Int32).Value = txtFacultyID.Text;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadKafedra();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();
            {
                int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

                MySqlCommand command = new MySqlCommand(
                    "DELETE FROM Kafedra WHERE kafedra_id=@id",
                    db.GetConnection()
                );

                command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

                db.OpenConnection();
                command.ExecuteNonQuery();
                db.CloseConnection();

                LoadKafedra();
            }

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            MySqlCommand command = new MySqlCommand(
            "UPDATE kafedra SET kafedra_name=@name, graduating=@grad, id_faculty=@idfac WHERE kafedra_id=@id",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = txtName.Text;

            command.Parameters.Add("@grad", MySqlDbType.Bit).Value = checkBoxGrad.Checked;

            command.Parameters.Add("@idfac", MySqlDbType.Int32).Value = txtFacultyID.Text;
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadKafedra();
        }

        private void kafedraForm_Load(object sender, EventArgs e)
        {
            LoadKafedra();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            try
            {
                checkBoxGrad.Checked = Convert.ToBoolean(dataGridView1.CurrentRow.Cells[2].Value);
            }
            catch {
            
            }
            txtFacultyID.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
        }
    }
}
