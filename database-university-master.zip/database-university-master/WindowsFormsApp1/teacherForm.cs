﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
    public partial class teacherForm : Form
    {
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtExperience.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtGender.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtKafedra.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            if (string.IsNullOrWhiteSpace(txtName.Text))
            {
                MessageBox.Show("Введите корректные данные", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }

            return true;
        }
        public void LoadTeachers()
        {
            DB db = new DB();

            MySqlDataAdapter adapter = new MySqlDataAdapter(
                "SELECT * FROM Teacher",
                db.GetConnection()
            );

            DataTable table = new DataTable();
            adapter.Fill(table);

            dataGridView1.DataSource = table;
        }
        public teacherForm()
        {
            InitializeComponent();
        }

        private void teacherForm_Load(object sender, EventArgs e)
        {
            LoadTeachers();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            MySqlCommand command = new MySqlCommand(
                "DELETE FROM Teacher WHERE teacher_id=@id",
                db.GetConnection()
            );

            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadTeachers();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            int id = Convert.ToInt32(dataGridView1.CurrentRow.Cells[0].Value);

            MySqlCommand command = new MySqlCommand(
            "UPDATE Teacher SET FIO_teacher=@name, experience=@exp, gender=@gen, kafedra_id=@dep WHERE teacher_id=@id",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = txtName.Text;
            command.Parameters.Add("@exp", MySqlDbType.Int32).Value = txtExperience.Text;
            command.Parameters.Add("@gen", MySqlDbType.VarChar).Value = txtGender.Text;
            command.Parameters.Add("@dep", MySqlDbType.Int32).Value = txtKafedra.Text;
            command.Parameters.Add("@id", MySqlDbType.Int32).Value = id;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadTeachers();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (!ValidateInputs()) return;
            DB db = new DB();

            MySqlCommand command = new MySqlCommand(
            "INSERT INTO Teacher(FIO_teacher,experience,gender,kafedra_id) VALUES(@name,@exp,@gen,@dep)",
            db.GetConnection());

            command.Parameters.Add("@name", MySqlDbType.VarChar).Value = txtName.Text;
            command.Parameters.Add("@exp", MySqlDbType.Int32).Value = txtExperience.Text;
            command.Parameters.Add("@gen", MySqlDbType.VarChar).Value = txtGender.Text;
            command.Parameters.Add("@dep", MySqlDbType.Int32).Value = txtKafedra.Text;

            db.OpenConnection();
            command.ExecuteNonQuery();
            db.CloseConnection();

            LoadTeachers();
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            txtName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtExperience.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtGender.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtKafedra.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mainMenuForm f1 = new mainMenuForm(); f1.Show(); Hide();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
